package tbr.aspect;

public class Aspect {

}
