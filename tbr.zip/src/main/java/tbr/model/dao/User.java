package tbr.model.dao;

public class User {

}
