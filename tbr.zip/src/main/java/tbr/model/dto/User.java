package tbr.model.dto;

public class User {

}
