package tbr.model.dto;

public class Social {

}
