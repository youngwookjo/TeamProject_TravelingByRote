package tbr.model.dto;

public class RawData {
	private String address;
	
	
	
}
